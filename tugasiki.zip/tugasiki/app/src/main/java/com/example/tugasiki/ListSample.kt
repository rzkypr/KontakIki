package com.example.tugasiki

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.tugasiki.model.ListData
import kotlinx.android.synthetic.main.rv_sample.*

class ListSample: AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.rv_sample)

        val listKontak = listOf(
            ListData(image = (R.drawable.bapak), nama = "Dosen Bapak Endra", nomor = "+62 896-6690-5702"),
            ListData(image = (R.drawable.bunda), nama = "Bunda", nomor = "+62 838-2931-2818"),
            ListData(image = (R.drawable.gagan), nama = "Gagan", nomor = "+62 821-5425-3799"),
            ListData(image = (R.drawable.oca), nama = "Oca", nomor = "+62 852-2113-9481"),
            ListData(image = (R.drawable.pacar), nama = "Pacar", nomor = "+62 882-2287-2697")
        )

        val listSampleAdapter = ListSampleAdapter(listKontak)

        recycler_view.apply {
            layoutManager = LinearLayoutManager(this@ListSample)
            adapter = listSampleAdapter
        }
    }
}