package com.example.tugasiki.model

data class ListData(val image: Int, val nama: String, val nomor: String)